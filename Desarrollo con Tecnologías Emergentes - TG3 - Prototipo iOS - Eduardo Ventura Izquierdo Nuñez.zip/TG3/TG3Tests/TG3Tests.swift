import XCTest

@testable import TG3

class TG3Tests: XCTestCase {
    override func setUp() {
        super.setUp()
        
    }
    
    override func tearDown() {
        super.tearDown()
        
    }
    
    func testExample() {
        
    }
    
    func testPerformanceExample() {
        self.measureBlock {
            
        }
        
    }
    
}