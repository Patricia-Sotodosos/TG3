import UIKit

class ViewController: UIViewController, NSXMLParserDelegate {
    @IBOutlet var storyboardCity: UILabel!
    @IBOutlet var storyboardTemperature: UILabel!
    @IBOutlet var storyboardText: UIImageView!
    @IBOutlet var storyboardUpdate: UIButton!
    
    //NSXML
    var xmlReader = NSXMLParser()
    var data = NSMutableArray()
    var elements = NSMutableDictionary()
    var element = NSString()
    
    //Forecast
    var city = NSMutableString()
    var date = NSMutableString()
    var temperature = NSMutableString()
    var text = NSMutableString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        storyboardUpdate.setImage(UIImage(named: "images/update.png"), forState: .Normal)
        self.beginParsing()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func update(sender: UIButton) {
        self.beginParsing()
        
    }
    
    //NSXML
    func beginParsing()
    {
        data = []
        xmlReader = NSXMLParser(contentsOfURL:(NSURL(string:"http://xml.tutiempo.net/xml/3768.xml"))!)!
        xmlReader.delegate = self
        xmlReader.parse()
        
        setData()
        
    }
    
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName
        if (elementName as NSString).isEqualToString("hora")
        {
            elements = NSMutableDictionary()
            city = NSMutableString()
            date = NSMutableString()
            temperature = NSMutableString()
            text = NSMutableString()
            
            elements = [:]
            city = ""
            date = ""
            temperature = ""
            text = ""
        }
        
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqualToString("hora") {
            if !date.isEqual(nil) {
                elements.setObject(date, forKey: "hora_datos")
            }
            if !temperature.isEqual(nil) {
                elements.setObject(temperature, forKey: "temperatura")
            }
            if !text.isEqual(nil) {
                elements.setObject(text, forKey: "texto")
            }
            data.addObject(elements)
            
        }
        
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String)
    {
        if element.isEqualToString("hora_datos") {
            date.appendString(string)
        } else if element.isEqualToString("temperatura") {
            temperature.appendString(string)
        } else if element.isEqualToString("texto") {
            text.appendString(string)
        }
        
    }
    
    //Data to interface
    func setData()
    {
        let currentDateTime = NSDate()
        let userCalendar = NSCalendar.currentCalendar()
        let requestedComponents: NSCalendarUnit = [NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day, NSCalendarUnit.Hour, NSCalendarUnit.Minute, NSCalendarUnit.Second]
        let dateTimeComponents = userCalendar.components(requestedComponents, fromDate: currentDateTime)
        
        for i in 0...(data.count-1){
            if(data.objectAtIndex(i).valueForKey("hora_datos")?.integerValue == dateTimeComponents.hour){
                storyboardCity.text = "Madrid"
                storyboardTemperature.text = (data.objectAtIndex(i).valueForKey("temperatura") as? String)! + "ºC"
                
                if((data.objectAtIndex(i).valueForKey("texto") as? String)!.rangeOfString("lluvia") != nil){
                    storyboardText.image = UIImage(named: "images/lluvia.png")
                } else if((data.objectAtIndex(i).valueForKey("texto") as? String)!.rangeOfString("cubierto") != nil){
                    storyboardText.image = UIImage(named: "images/cubierto.png")
                } else if((data.objectAtIndex(i).valueForKey("texto") as? String)!.rangeOfString("nuboso") != nil){
                    storyboardText.image = UIImage(named: "images/nuboso.png")
                } else{
                    storyboardText.image = UIImage(named: "images/soleado.png")
                }
                break
                
            }
            
        }
        
    }
    
}