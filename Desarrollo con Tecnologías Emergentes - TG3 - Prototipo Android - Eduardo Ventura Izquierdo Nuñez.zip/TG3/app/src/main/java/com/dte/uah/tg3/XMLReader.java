package com.dte.uah.tg3;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class XMLReader {
    public static ArrayList<Forecast> getForecast(URL url){
        ArrayList<Forecast> arrayList = new ArrayList<Forecast>();

        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            Document document = documentBuilder.parse(url.openStream());

            //Normalize
            document.getDocumentElement().normalize();

            //City
            Element elementoLocalidad =(Element) document.getElementsByTagName("localidad").item(0);
            String localidad = elementoLocalidad.getElementsByTagName("nombre").item(0).getTextContent();

            //Data
            NodeList listOfHoras = document.getElementsByTagName("hora");
            for (int i = 0; i< listOfHoras.getLength(); i++){
                Element element = (Element) listOfHoras.item(i);

                //Forecast data
                Forecast forecast = new Forecast();
                forecast.setCity(localidad);
                forecast.setDate(new SimpleDateFormat("yyyy-MM-dd/hh:mm").parse(element.getElementsByTagName("fecha").item(0).getTextContent() + "/" + element.getElementsByTagName("hora_datos").item(0).getTextContent()));
                forecast.setTemperature(Integer.parseInt(element.getElementsByTagName("temperatura").item(0).getTextContent()));
                forecast.setText(element.getElementsByTagName("texto").item(0).getTextContent());
                arrayList.add(forecast);

            }

        }catch(Exception e){}
        return arrayList;

    }

}