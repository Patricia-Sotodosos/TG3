package com.dte.uah.tg3;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.net.URL;
import java.util.ArrayList;

public class Main extends AppCompatActivity {
    private ArrayList<Forecast> arrayList = new ArrayList<Forecast>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        //StrictMode
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        this.getValues();

    }

    private void getValues(){
        TextView city = (TextView)findViewById(R.id.ciudad);
        TextView temperature = (TextView)findViewById(R.id.temperatura);

        try{
            URL url = new URL("http://xml.tutiempo.net/xml/3768.xml");
            this.arrayList = XMLReader.getForecast(url);
            city.setText(Best.getBestForecast(this.arrayList).getCity());
            temperature.setText(""+Best.getBestForecast(this.arrayList).getTemperature()+"ºC");
            this.updatePicture(Best.getBestForecast(this.arrayList));
        }catch(Exception e){};

    }

    private void updatePicture(Forecast forecast){
        ImageView imageView = (ImageView)findViewById(R.id.estado);

        if(forecast.getText().contains("lluvia")) imageView.setImageResource(R.drawable.lluvia);
        else if(forecast.getText().contains("cubierto")) imageView.setImageResource(R.drawable.cubierto);
        else if(forecast.getText().contains("nuboso")) imageView.setImageResource(R.drawable.nuboso);
        else imageView.setImageResource(R.drawable.soleado);

    }

    public void update(View view){
        this.getValues();
    }

}