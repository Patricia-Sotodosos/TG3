package com.dte.uah.tg3;

import java.util.ArrayList;
import java.util.Calendar;

public class Best {
    public static Forecast getBestForecast(ArrayList<Forecast> arrayList){
        Calendar calendar = Calendar.getInstance();
        int i = 0;
        while(i < arrayList.size()){
            if(arrayList.get(i).getDate().getHours() == calendar.get(Calendar.HOUR_OF_DAY)){
                return arrayList.get(i);
            }
            else i++;

        }
        return null;

    }

}